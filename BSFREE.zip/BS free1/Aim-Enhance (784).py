def aimlock_enemy():
    while True:
        if enemy_in_sight():
            aim_at(enemy)
            shoot()
        else:
            search_for_enemy()

def enemy_in_sight():
    # Logic to determine if an enemy is in sight
    pass

def aim_at(enemy):
    # Logic to aim at the enemy
    pass

def shoot():
    # Logic to shoot
    pass

def search_for_enemy():
    # Logic to search for enemies
    pass

aimlock_enemy()