<config namespace :script damage hero /com.mobile.legends/suntik damage/massage/app setings(damage high)
"hero list"


<true namespace:heroes"zilong damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
<true namespace:heroes"yin damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  

<true namespace:heroes"chou damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
<true namespace:heroes"nana damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
  <true namespace:heroes"nolan damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
 
  <true namespace:heroes"clode damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public attack speed damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
   <true namespace:heroes"clode damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public attack speed damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
  <true namespace:heroes"miya damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public attack speed damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script 
  
  
  
   <true namespace:heroes"dyroth damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public attack speed damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
  
 <true namespace:heroes"ling damage"
  <true public phisical damage=9999999999%
  <true public majical damage=9999999999%
  <true public critical damage=999999999%
  <true public attack speed damage=999999999%
  <true public true damage=999999999%
  <true dynamic damage seluruh=999999999999999%
  <true dynamic base turet damage=999999999%
  <true dynamic heroes damage=999999999%
  <fast level hero=true
  <false
  <fast farming hero=true
  <false
  <working to script
  
  
<true false damage vvip foreach=99%mode damage heroes funcition heroes damage=99% lucy damage=99% high damage=99% heroes damage script criticalcance damage=9999999999%
  
<namespace:phisical damage puncition high heroes lawan mode lock damage phisical=9999999999% struct modegot criticalcance operator throw

<namespace: no clowdwon heroes=try- false
            <false
            <true
            no clowdwon heroes=99%
           <skill1_no clowdwon=true
           <skill2_no clowdwon=true
           <skill3_no clowdwon=true
           <skill4_no clowdwon=true

//config on