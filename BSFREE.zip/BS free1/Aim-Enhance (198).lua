function highDamage()
    local player = getPlayer()
    local damageMultiplier = 56
    local baseDamage = player:getBaseDamage()
    local newDamage = baseDamage * damageMultiplier

    player:setDamage(newDamage)
    print("Damage set to: " .. newDamage)
end

highDamage()