[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireM13":"100%"

"AimassistM13":"100%"

"AimbotM13":"100%"

"AimlockM13":"MAX"

"HipfireSpeedM14:"MAX"

