[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47:"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"

[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


[Script/ShadowTrackerExtra.DamageType]

"AimAssist":"MAX"

"Aimlock":"MAX"

"Aimbot":"MAX"

"HeadshotAimassist":"MAX"

"HeadshotAimbot":"MAX"

"HeadshotAimlock":"100%"

"Hipfire":"100%"

"HipfireAK-47":"100%"

"AimassistAK-47":"100%"

"AimbotAK-47":"100%"

"AimlockAK-47":"MAX"

"HipfireSpeedAK-47":"MAX"


end

My Savitar name:)