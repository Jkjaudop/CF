[/Script/Engine.damageSettings]



[BasicSetting]
r.AimAssist=3 + "100%"
t.AimLock=3 + "100%"
AimBot=3 + "100%"
+CVars=r.AimAssist=3 + "100%"
+CVars=AimAssist=3 + "100%"

[GameSetting]
r.AimAssist=3 + "100%"
t.AimScope=3 + "100%"
AimAssist=3 + "100%"
+CVars=r.AimAssist=3 + "100%"
+CVars=AimAssist=3 + "100%"

[SaveGames]
r.AimAssist=3 + "100%"
t.AimAssist=3 + "100%"
AimAssist=3 + "100%"
+CVars=r.AimAssist=3 + "100%"
+CVars=AimAssist=3 + "100%"

[/Script/Engine.PhysicsSettings]
AimAssistLockHead="MAX"
AimLockEnemy="MAX"
AimLockTarget="MAX"
AimAssist="MAX"
r.AimAssist="MAX"
BulletDamage="MAX"
SuperHighDamage="MAX"
HeadShot="MAX"
Damage="MAX"
MagicBullet="MAX"
BulletTracker="MAX"
All Guns Aimlock="100%"
High Damage2X="MAX"
AimAssist SMG ="MAX"
AimLock Head Hipfire SMG ="100%"
AimbotM4="MAX"
AimlockM4="100%"
AimAssistM4="MAX"
High Damage="100%"
UltraDamage="100%"
MovmentSpeed="MAX"
FullGunsAimLock Aimbot AimAssist="MAX"