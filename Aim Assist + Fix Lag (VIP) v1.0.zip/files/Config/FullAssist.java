[Script/ShadowTrackerExtra.DamageType]


SNIPER Headshotaimlock:"MAX%"
M4 Aimlock Aimbot Aimassist:"MAX'
UltraAimlock M4:"100%"
Highaimassist:M4:"MAX"
HighAccuracyM4:"100%"
Accuracy of the arrow AllGuns:"MAX"
Ultra AccuracySMG Guns:"MAX"
FullGuns Aimbot:"100%"
FullFireSpeed:"MAX"
Full Headshot AllGuns:"MAX"
FullAimAssist:"MAX"
High DamageAllGuns:"100%
M4Accuracy:"MAX"
AK-47Accuracy:"MAX"
AK-47Headshotaimlock:"MAX"
AimlockAK-47:"MAX"
AimbotAK-47:"100%"
AimAssistM4:"MAX"
AimlockM4:"MAX"
HighAccuracySMG:"MAX"
FullAccuracyASSAULT:"100%"
AllGunsAimAssist:"MAX"
AllDamagGuns:"100%"
ScopeSpeed:"MAX"
SniperFireSpeed:100%
BulletSpeed:"MAX"
BulletDamage:"100%"
BulletFireSpeed:"MAX"
