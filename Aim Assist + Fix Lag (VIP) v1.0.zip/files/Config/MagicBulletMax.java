[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"