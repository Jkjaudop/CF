[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"

[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"emies.Setting

[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"

[script/shadowtrackerextra/useraimbot]
aimbotenable = true
aimbot = "100%"

[aimex.setting]
aimlockenable = true
aimlock = "100%"

[aimenemies.setting]
magicbulletenable = true
magicbullet = "100%"

[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"

[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"

[Script/ShadowTrackerExtra/UserAimbot]
AimbotEnable = True
Aimbot = "100%"

[AimEx.Setting]
AimlockEnable = True
Aimlock = "100%"

[AimEnemies.Setting]
MagicBulletEnable = True
MagicBullet = "100%"