local aimAssist = {}

function aimAssist:enable()
    -- Code to enable aim assist
    print("Aim Assist Enabled")
end

function aimAssist:setMaxDistance(distance)
    -- Code to set maximum distance for aim assist
    self.maxDistance = distance
    print("Max Distance Set to: " .. distance)
end

function aimAssist:aimAtTarget(target)
    -- Code to aim at the specified target
    if target.distance <= self.maxDistance then
        print("Aiming at target: " .. target.name)
    else
        print("Target out of range")
    end
end

-- Usage
aimAssist:enable()
aimAssist:setMaxDistance(100) -- Set max distance to 100 units
aimAssist:aimAtTarget({name = "Enemy", distance = 50}) -- Example target