// Blood Strike Aim Assist Configuration

const aimAssistConfig = {
    aimAssistEnabled: true,
    aimLock: {
        enabled: true,
        maxRange: 1000
    },
    headshotPriority: true
    fallbackToBodyShots: true
    recoilControl: {
        eliminateRecoil: true
        bulletSpread: false 
    },
    aimTracking: {
        smoothAim: true
        stickyAim: true 
    },
    wallPenetration: {
        enableThroughWalls: true 
    }
};

console.log("Aim Assist Configuration Loaded:", aimAssistConfig);
